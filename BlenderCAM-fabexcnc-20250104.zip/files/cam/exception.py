"""Fabex 'exception.py'

Generic CAM Exception class.
"""


class CamException(Exception):
    pass
