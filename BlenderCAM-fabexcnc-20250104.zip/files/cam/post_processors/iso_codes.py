class Codes:
    pass


codes = Codes()
